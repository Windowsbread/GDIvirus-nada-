#ifndef HEADER_B00ECE6762DC5F9
#define HEADER_B00ECE6762DC5F9

#pragma once
#include <windows.h>
#include <mmsystem.h>
#include <functional>

#pragma comment(lib, "winmm.lib")

namespace bytebeat
{
    class Player {
    public:
        int sampleRate;
        int length;
        unsigned char* buffer;

        Player(int seconds = 10, int rate = 8000) {
            sampleRate = rate;
            length = seconds * sampleRate;
            buffer = new unsigned char[length];
        }

        ~Player() {
            delete[] buffer;
        }

        // Fun��o para gerar bytebeat
        void Generate(std::function<unsigned char(int)> func) {
            for (int t = 0; t < length; t++) {
                buffer[t] = func(t);
            }
        }

        // Tocar o �udio
        void Play() {
            WAVEFORMATEX wfx = {0};
            wfx.wFormatTag = WAVE_FORMAT_PCM;
            wfx.nChannels = 1;
            wfx.nSamplesPerSec = sampleRate;
            wfx.wBitsPerSample = 8;
            wfx.nBlockAlign = 1;
            wfx.nAvgBytesPerSec = sampleRate;
            wfx.cbSize = 0;

            HWAVEOUT hWave;
            waveOutOpen(&hWave, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

            WAVEHDR header = {0};
            header.lpData = (LPSTR)buffer;
            header.dwBufferLength = length;

            waveOutPrepareHeader(hWave, &header, sizeof(WAVEHDR));
            waveOutWrite(hWave, &header, sizeof(WAVEHDR));

            // esperar terminar
            while (!(header.dwFlags & WHDR_DONE)) {
                Sleep(10);
            }

            waveOutUnprepareHeader(hWave, &header, sizeof(WAVEHDR));
            waveOutClose(hWave);
        }
    };
}
#endif // header guard 

