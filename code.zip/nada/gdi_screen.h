#ifndef HEADER_CDDFDC971721AED6
#define HEADER_CDDFDC971721AED6

#pragma once
#include <Windows.h>

namespace gdiscreen
{
    class Screen {
    public:
        HWND desktop;
        HDC  hdc;
        int w, h;

        Screen() {
            desktop = GetDesktopWindow();
            hdc = GetDC(desktop);
            w = GetSystemMetrics(SM_CXSCREEN);
            h = GetSystemMetrics(SM_CYSCREEN);
        }

        ~Screen() {
            ReleaseDC(desktop, hdc);
        }

        void Shift(int amount = 30) {
            BitBlt(hdc,
                   rand() % amount,
                   rand() % amount,
                   w, h,
                   hdc,
                   0, 0,
                   SRCCOPY);
        }

        void Tunnel(int shrink = 50) {
            StretchBlt(hdc,
                       shrink, shrink,
                       w - shrink * 2,
                       h - shrink * 2,
                       hdc,
                       0, 0,
                       w, h,
                       SRCCOPY);
        }

        void Invert() {
            PatBlt(hdc, 0, 0, w, h, DSTINVERT);
        }

        void Warp(int power = 10) {
            int rx = (rand() % power) - power / 2;
            int ry = (rand() % power) - power / 2;

            StretchBlt(hdc,
                       rx, ry,
                       w - rx,
                       h - ry,
                       hdc,
                       0, 0,
                       w, h,
                       SRCCOPY);
        }

        // Dentro de gdi_screen.h
void GlitchLines(int maxShift) {
    // pega resolu��o da tela
    int width = w;
    int height = h;

    // criar bitmap tempor�rio para copiar linha
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBmp = CreateCompatibleBitmap(hdc, width, 1); // 1 linha
    SelectObject(memDC, memBmp);

    for (int y = 0; y < height; y++) {
        // copiar linha y
        BitBlt(memDC, 0, 0, width, 1, hdc, 0, y, SRCCOPY);

        // shift aleat�rio
        int shift = (rand() % (2 * maxShift + 1)) - maxShift; // -maxShift..+maxShift

        // desenhar linha deslocada
        BitBlt(hdc, shift, y, width, 1, memDC, 0, 0, SRCCOPY);
    }

    DeleteObject(memBmp);
    DeleteDC(memDC);
}
void GlitchLinesFast(int maxShift) {
    static HDC memDC = CreateCompatibleDC(hdc);
    static HBITMAP memBmp = CreateCompatibleBitmap(hdc, w, 1);
    static bool init = false;

    if(!init) {
        SelectObject(memDC, memBmp);
        init = true;
    }

    for (int y = 0; y < h; y++) {
        // copiar linha
        BitBlt(memDC, 0, 0, w, 1, hdc, 0, y, SRCCOPY);

        // shift aleat�rio
        int shift = (rand() % (2 * maxShift + 1)) - maxShift;

        // desenhar de volta
        BitBlt(hdc, shift, y, w, 1, memDC, 0, 0, SRCCOPY);
    }
}


    };

}
#endif // header guard

